# Fizika – inicijalni test (Android)

Mala Android aplikacija za ponavljanje gradiva fizike iz osnovne škole.

## Šta sadrži
- 30 pitanja iz ključnih oblasti fizike.
- Svako pitanje vredi 1 bod.
- Automatska provera odgovora i kratko objašnjenje.
- Na kraju se prikazuju broj tačnih odgovora i procenat uspešnosti.
- Ne koristi ocene 1–5: završni rezultat je procenat.
- Pitanja se nasumično raspoređuju pri svakom novom pokušaju.
- Radi bez interneta.

## Kako napraviti APK
1. Otvorite folder projekta u Android Studio.
2. Sačekajte da se Gradle sinhronizuje.
3. Izaberite **Build > Build App Bundles or APKs > Build APK(s)**.
4. APK će biti u `app/build/outputs/apk/debug/app-debug.apk`.

Za distribuciju učenicima možete napraviti i potpisani APK preko:
**Build > Generate Signed App Bundle or APK > APK**.
